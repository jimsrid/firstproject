const expenses = [
    {
        id: 1,
        name: "Video Games",
        price: 1000
    },
    {
        id: 2,
        name: "Online Shopping",
        price: 2000
    },
    {
        id: 3,
        name: "Gym",
        price: 800
    },
    {
        id: 4,
        name: "Spotify",
        price: 125
    },
    {
        id: 5,
        name: "Car Maintenance",
        price: 5000
    },
    {
        id: 6,
        name: "Grocery",
        price: 10000
    },
    {
        id: 7,
        name: "Rent",
        price: 5000
    },
    {
        id: 8,
        name: "Travel",
        price: 500
    },
    {
        id: 9,
        name: "Insurance",
        price: 1800
    },
    {
        id: 10,
        name: "Emergency",
        price: 1000
    },
]

export default expenses