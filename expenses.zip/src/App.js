import logo from './logo.svg';
import './App.css';
import Todo from './components/Todo';
import expenses from './data';


function App() {
  return (
    <div className="App">
      Expense Tracker
     {expenses.map((expense) => {
       return <Todo key={expense.id} name={expense.name} price={expense.price}/>
     })}
     Total: 
     {expenses.reduce((total,value) => {
                return total + value.price;
            }, 0)}
    </div>
  );
}

export default App;
