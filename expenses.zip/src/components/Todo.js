import './Todo.css'
function Todo(props) {
    const handleClick= () => {
        alert("You clicked " + props.name + " - Php " + props.price)
    }
    return(
        <center><div className="container">
            <div className="name" onClick={handleClick}>{props.name}</div>
            <div className="price" >{props.price}</div>
        </div>
        </center>
        
    )
}
export default Todo;